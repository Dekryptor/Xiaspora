﻿namespace EloBuddy.Loader.Controls
{
    /// <summary>
    ///     Interaction logic for Separator.xaml
    /// </summary>
    public partial class Separator
    {
        public Separator()
        {
            InitializeComponent();
        }
    }
}
