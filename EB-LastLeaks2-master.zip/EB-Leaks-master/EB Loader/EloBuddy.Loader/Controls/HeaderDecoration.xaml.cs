﻿namespace EloBuddy.Loader.Controls
{
    /// <summary>
    ///     Interaction logic for HeaderDecoration.xaml
    /// </summary>
    public partial class HeaderDecoration
    {
        public HeaderDecoration()
        {
            InitializeComponent();
        }
    }
}
