﻿namespace EloBuddy.Loader.Controls
{
    /// <summary>
    ///     Interaction logic for NewsControl.xaml
    /// </summary>
    public partial class NewsControl
    {
        public NewsControl()
        {
            InitializeComponent();
        }
    }
}
