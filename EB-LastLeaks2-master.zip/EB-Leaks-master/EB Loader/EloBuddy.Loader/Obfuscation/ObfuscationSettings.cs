﻿using System.Reflection;

// symbols
[assembly: Obfuscation(Feature = "encrypt symbol names with password tsHTrYmOYlgWQ5eEv1BiSU2ra77spII3xY8sRJlicD8aDoS88GHwbudKZEZycfRF4KxJYVN9EUv5BydaEvZEGnF3Lnb9a4", Exclude = false)]

// string encryption
[assembly: Obfuscation(Feature = "string encryption", Exclude = false)]

// resource encryption
[assembly: Obfuscation(Feature = "encrypt resources", Exclude = false)]

// virtualization
[assembly: Obfuscation(Feature = "Apply to type EloBuddy.Loader.Data.Authenticator: apply to member *: virtualization", Exclude = false)]


