﻿namespace EloBuddy.Loader.Views
{
    /// <summary>
    ///     Interaction logic for DummyWindow.xaml
    /// </summary>
    public partial class DummyWindow
    {
        public DummyWindow()
        {
            InitializeComponent();
        }
    }
}
