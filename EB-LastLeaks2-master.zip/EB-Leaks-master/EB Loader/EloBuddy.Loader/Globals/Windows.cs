﻿using Elobuddy.Loader.Views;

namespace EloBuddy.Loader.Globals
{
    public static class Windows
    {
        public static MainWindow MainWindow;
    }
}
