﻿namespace EloBuddy.Loader.Protections
{
    internal abstract class ProtectionPhase
    {
        protected internal abstract void Execute();
    }
}
