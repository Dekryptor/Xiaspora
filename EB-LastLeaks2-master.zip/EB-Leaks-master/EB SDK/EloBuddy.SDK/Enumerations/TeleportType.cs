﻿namespace EloBuddy.SDK.Enumerations
{
    public enum TeleportType
    {
        Recall,
        Teleport,
        TwistedFate,
        Shen,
        Unknown
    }
}
