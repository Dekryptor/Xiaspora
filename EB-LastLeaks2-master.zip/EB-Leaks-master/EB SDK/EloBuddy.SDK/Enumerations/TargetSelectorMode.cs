﻿namespace EloBuddy.SDK.Enumerations
{
    public enum TargetSelectorMode
    {
        Auto,
        MostStack,
        MostAbilityPower,
        MostAttackDamage,
        LeastHealth,
        Closest,
        HighestPriority,
        LessAttack,
        LessCast,
        NearMouse
    }
}
