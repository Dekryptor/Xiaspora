﻿namespace EloBuddy.SDK.Enumerations
{
    public enum DangerLevel
    {
        High,
        Medium,
        Low
    }
}
