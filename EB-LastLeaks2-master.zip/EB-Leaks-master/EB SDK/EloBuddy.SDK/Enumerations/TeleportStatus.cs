﻿namespace EloBuddy.SDK.Enumerations
{
    public enum TeleportStatus
    {
        Start,
        Abort,
        Finish,
        Unknown
    }
}
