﻿namespace EloBuddy.SDK.Enumerations
{
    public enum SkillShotType
    {
        Linear,
        Circular,
        Cone
    }
}
