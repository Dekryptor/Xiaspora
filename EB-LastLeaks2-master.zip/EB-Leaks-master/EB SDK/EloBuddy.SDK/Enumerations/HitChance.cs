﻿namespace EloBuddy.SDK.Enumerations
{
    public enum HitChance
    {
        Unknown,
        Impossible,
        Collision,
        Low,
        AveragePoint,
        Medium,
        High,
        Dashing,
        Immobile
    }
}
