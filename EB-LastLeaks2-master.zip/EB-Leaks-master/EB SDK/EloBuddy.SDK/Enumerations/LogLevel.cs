﻿namespace EloBuddy.SDK.Enumerations
{
    public enum LogLevel
    {
        Debug,
        Error,
        Info,
        Warn
    }
}
