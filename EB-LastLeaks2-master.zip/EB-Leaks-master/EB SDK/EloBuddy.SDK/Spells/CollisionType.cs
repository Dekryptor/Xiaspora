﻿namespace EloBuddy.SDK.Spells
{
    public enum CollisionType
    {
        AiHeroClient,
        ObjAiMinion,
        YasuoWall
    }
}
