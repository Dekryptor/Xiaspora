﻿namespace EloBuddy.SDK.Spells
{
    public enum SpellType
    {
        Self,
        Circle,
        Line,
        Cone,
        Ring,
        Arc,
        MissileLine,
        MissileAoe
    }
}
